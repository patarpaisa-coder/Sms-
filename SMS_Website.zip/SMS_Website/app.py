from flask import Flask, request, session, redirect, url_for, render_template_string, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

app = Flask(__name__)
app.secret_key = "change-this-secret-key"

DB = "sms.db"

BG = "https://i.ibb.co/1G8DpvmR/f6f5713feb79f5d6f45600b0d86b7570.webp"

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS messages(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone TEXT NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")
    con.commit()
    con.close()

def logged_in(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "phone" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

CSS = f"""
*{{box-sizing:border-box}}
body{{
 margin:0; min-height:100vh; font-family:Arial,sans-serif;
 color:white; background:#111 url('{BG}') center/cover fixed no-repeat;
}}
body:before{{
 content:""; position:fixed; inset:0; background:rgba(0,0,0,.48);
 z-index:-1;
}}
.box{{
 width:min(92%,520px); margin:7vh auto; padding:28px;
 border-radius:24px; background:rgba(10,10,20,.70);
 backdrop-filter:blur(12px); box-shadow:0 10px 40px rgba(0,0,0,.45);
}}
h1{{text-align:center;margin:0 0 22px;font-size:34px}}
input,textarea{{
 width:100%; padding:15px; margin:9px 0; border:1px solid rgba(255,255,255,.25);
 border-radius:14px; background:rgba(255,255,255,.12); color:white; outline:none;
}}
textarea{{min-height:180px;resize:vertical}}
button,.btn{{
 display:inline-block; width:100%; padding:14px; margin-top:10px; border:0;
 border-radius:14px; background:#00d4ff; color:#001018; font-weight:bold;
 text-decoration:none; text-align:center; cursor:pointer;
}}
.small{{text-align:center;opacity:.85;font-size:13px}}
.msg{{background:rgba(255,255,255,.10);padding:15px;margin:12px 0;border-radius:15px}}
.msg b{{color:#7ee7ff}}
a{{color:#fff}}
"""

LOGIN = f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SMS Login</title><style>{CSS}</style></head><body>
<div class="box"><h1>SMS</h1>
<form method="post">
<input name="phone" placeholder="Mobile Number" required>
<input name="password" type="password" placeholder="Password" required>
<button>Login / Continue</button>
</form>
<p class="small">اپنا نمبر اور پاس ورڈ درج کریں۔ پہلی بار یہی نمبر/پاس ورڈ دینے سے اکاؤنٹ بن جائے گا۔</p>
</div></body></html>"""

HOME = f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SMS</title><style>{CSS}</style></head><body>
<div class="box"><h1>SMS</h1>
<p>Logged in as: <b>{{{{phone}}}}</b></p>
<form method="post">
<textarea name="message" maxlength="5000" placeholder="اپنا میسج یہاں لکھیں..." required></textarea>
<button type="submit">Submit / Send</button>
</form>
<a class="btn" href="/logout">Logout</a>
<p class="small">آپ کا میسج server کے database میں نمبر کے ساتھ محفوظ ہوگا۔</p>
</div></body></html>"""

INBOX = f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SMS Inbox</title><style>{CSS}</style></head><body>
<div class="box"><h1>SMS Inbox</h1>
{{% for m in messages %}}
<div class="msg"><b>Number:</b> {{{{m['phone']}}}}<br>
<b>Time:</b> {{{{m['created_at']}}}}<br><br>
{{{{m['message']}}}}</div>
{{% else %}}<p>No messages yet.</p>{{% endfor %}}
<a class="btn" href="/">Back</a>
</div></body></html>"""

@app.route("/", methods=["GET","POST"])
@logged_in
def home():
    if request.method == "POST":
        msg = request.form.get("message","").strip()
        if msg:
            con = db()
            con.execute("INSERT INTO messages(phone,message) VALUES(?,?)",
                        (session["phone"], msg))
            con.commit(); con.close()
            return redirect(url_for("home"))
    return render_template_string(HOME, phone=session["phone"])

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        phone = request.form.get("phone","").strip()
        password = request.form.get("password","")
        if not phone or not password:
            return "Number and password required", 400
        con = db()
        user = con.execute("SELECT * FROM users WHERE phone=?", (phone,)).fetchone()
        if user:
            if not check_password_hash(user["password"], password):
                con.close()
                return "Wrong password for this number.", 401
        else:
            con.execute("INSERT INTO users(phone,password) VALUES(?,?)",
                        (phone, generate_password_hash(password)))
            con.commit()
        con.close()
        session["phone"] = phone
        return redirect(url_for("home"))
    return render_template_string(LOGIN)

@app.route("/inbox")
def inbox():
    # Simple local inbox for the site owner. For public deployment, protect this route.
    con = db()
    messages = con.execute("SELECT * FROM messages ORDER BY id DESC").fetchall()
    con.close()
    return render_template_string(INBOX, messages=messages)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)
