# SMS Website

## Features
- Mobile number + password login
- First login automatically creates the account
- One-page message screen
- Messages are stored in SQLite with sender number and time
- `/inbox` shows all received messages
- Full-screen background image from the supplied image URL
- Works with Flask on Kali Linux / Termux

## Run
```bash
cd SMS_Website
python -m pip install flask werkzeug
python app.py
```

Open:
http://127.0.0.1:5000

Inbox:
http://127.0.0.1:5000/inbox

For internet access from your own device, you can use a legitimate tunnel such as Cloudflare Tunnel.

IMPORTANT:
`/inbox` is intentionally simple for quick local testing. Before putting this site on the public Internet, protect the inbox with an owner/admin login or another access-control method.
